'use strict';

module.exports = {
  extends: 'recommended'
};
