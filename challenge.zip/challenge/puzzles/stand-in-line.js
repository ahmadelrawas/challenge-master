'use strict';

function logAfter(seconds, callback) {
  setTimeout(() => console.log(`${seconds} seconds have passed`) + (callback && callback()), seconds * 1000);
}

let standInLine = (() => {
  // Fill the missing code here
})();

standInLine(logAfter)(5);
standInLine(logAfter)(3);
standInLine(logAfter)(4);
