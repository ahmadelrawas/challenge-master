'use strict';

function madAdd(/* fill code here */) {
  // fill code here
}

console.log(+madAdd(1, 3)(1)(2, 3, 5)); // logs 15
console.log(+madAdd(2)(madAdd(madAdd(1, 3))(2, 3, 0, 2))); // logs 13
