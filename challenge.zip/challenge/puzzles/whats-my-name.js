'use strict';

let person = {
  name: 'Teddy',

  // Add code here and only here
};

{
  let whatsMyName = person.whatsMyName;
  console.log(person.whatsMyName()); // logs `Teddy`
  console.log(whatsMyName()); // logs `Teddy`
  person.name = 'Rami'
  console.log(person.whatsMyName()); // logs `Rami`
  console.log(whatsMyName()); // logs `Rami`
}
